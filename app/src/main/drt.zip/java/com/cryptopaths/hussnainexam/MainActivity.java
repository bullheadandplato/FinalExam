package com.cryptopaths.hussnainexam;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper mDbHelper;
    private int count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDbHelper=new DatabaseHelper(this);
    }

    public void insertButtonClicked(View view){
        mDbHelper.insertData(count++,((EditText)(findViewById(R.id.editText))).getText().toString());
        ((TextView)findViewById(R.id.resultTextView)).setText(mDbHelper.findName(count-1));


    }
}
